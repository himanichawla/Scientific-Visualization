#pragma once

#include <string>

class Vector_oper
{
public:

  // The element of the vector
  double x;
  double y;
  double z;

  /*
  Constructor of the class
  */
  Vector_oper(double x, double y, double z) : x(x), y(y), z(z) { }

  /*
  Returns the magnitude of the vector
  */
  double magnitude();

  /*
  Normalizes the vector
  */
  Vector_oper* normalize();

  /*
  Multiply the vector by the given scalar
  */
  Vector_oper* multiply(double s);

  /*
  Clones the vector
  */
  Vector_oper* clone();

  /*
  Adds the value of the given vector
  */
  Vector_oper* add(Vector_oper* B);

  /*
  Subtracts the values of the given vector
  */
  Vector_oper* sub(Vector_oper* B);

  /*
  Calculates the dot product with vector B
  */
  double dot(Vector_oper* B);

  /*
  Calculates the cross product with vector B
  */
  Vector_oper* cross(Vector_oper* B);

  /*
  Calculates the square euclidean distance to another vector
  */
  double squareDistance(Vector_oper* B);

  /*
  Calculates the euclidean distance to another vector
  */
  double distance(Vector_oper* B);

  /*
  Returns the intyerpolated point using parameter t and point B
  */
  Vector_oper* interpolate(double t, Vector_oper* B);

  /*
  */
  bool equal(Vector_oper* B);

  /*
  Assigns the (x, y, z) values to the vector
  */
  Vector_oper* set(double x, double y, double z);

  /*
  */
  std::string toString();

};
