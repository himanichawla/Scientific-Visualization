#define _USE_MATH_DEFINES
#include <math.h>
#include <vtkPolyData.h>
#include <vtkSmartPointer.h>
#include <vtkPolyDataMapper.h>
#include <vtkActor.h>
#include <vtkRenderWindow.h>
#include <vtkRenderer.h>
#include <vtkRenderWindowInteractor.h>
#include <string>
#include "vtkCamera.h"
#include "vtkLight.h"
#include "vtkOpenGLPolyDataMapper.h"
#include <vtkArrowSource.h>
#include <vtkPointData.h>
#include <vtkPolyDataReader.h>
#include <vtkPoints.h>
#include <vtkUnsignedCharArray.h>
#include <vtkFloatArray.h>
#include <vtkDoubleArray.h>
#include <vtkPNGWriter.h>
#include <vtkCellArray.h>
#include <vtkDataSetReader.h>
#include <vtkRectilinearGrid.h>
#include <vtkStructuredGrid.h>
#include <vtkAppendPolyData.h>
#include <vtkCamera.h>
#include <vtkDataSetMapper.h>
#include <vtkRenderWindow.h>
#include <vtkPlane.h>
#include <vtkSmartPointer.h>
#include <vtkCellData.h>
#include <vtkExtractRectilinearGrid.h>
#include <vtkImageData.h>
#include <vtkImageViewer2.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <random>
#include <vector>
#include <math.h>
#include "Vector_oper.h"
#include "Vector_oper.cpp"
#include <time.h>

void
WriteImage(vtkImageData *img, const char *filename)
{
    std::string full_filename = filename;
    full_filename += ".png";
    vtkPNGWriter *writer = vtkPNGWriter::New();
    writer->SetInputData(img);
    writer->SetFileName(full_filename.c_str());
    writer->Write();
    writer->Delete();
}



vtkSmartPointer<vtkImageData> generateWhiteNoise(int width, int height)
{
	
	vtkSmartPointer<vtkImageData> noise = vtkSmartPointer<vtkImageData>::New();
	noise->SetDimensions(width, height, 1);
	noise->AllocateScalars(VTK_UNSIGNED_CHAR, 3);

	
	std::default_random_engine generator;
	std::uniform_int_distribution<int> distribution(0, 255);

	
	for (int y = 0; y < height; y += 1)
	{
		for (int x = 0; x < width; x += 1)
		{
			
			int randomValue = distribution(generator);

			
			unsigned char* RGB = static_cast<unsigned char*>(noise->GetScalarPointer(x, y, 0));
			RGB[0] = (unsigned char)(randomValue);
			RGB[1] = (unsigned char)(randomValue);
			RGB[2] = (unsigned char)(randomValue);
		}
	}

	
	return noise;
}


Vector_oper* Interpolation_cal(Vector_oper* P1, Vector_oper* P2, Vector_oper* P3, Vector_oper* P4, double u, double v,int* bbox)
{
	double t1 = (u -bbox[0])/(bbox[2]-bbox[0]);
	double t2 = (v - bbox[1])/(bbox[3]-bbox[1]);
	Vector_oper* term1 = P1->clone();
	Vector_oper* term2 = P2->clone()->sub(P1)->multiply(t1);
	Vector_oper* inter1 = term1->clone()->add(term2);
	Vector_oper* term3 = P2->clone();
	Vector_oper* term4 = P3->clone()->sub(P2)->multiply(t1);
	Vector_oper* inter2 = term3->clone()->add(term4);
	Vector_oper* term5 = inter1->clone();
	Vector_oper* term6 = inter2->clone()->sub(inter1)->multiply(t2);
	Vector_oper* result = term5->clone()->add(term6);
	//Vector_oper* result = term1->clone()->add(term2)->add(term3)->add(term4);
	return result;
}


Vector_oper* EvaluateFieldAtLocation(int x, int y, std::vector<Vector_oper*>* data, int n, int m)
{

	double u = ((double)(x * (n-1))) / 255.0;
	double v = ((double)(y * (m-1))) / 255.0;
	int bbox[4];
	bbox[0] = floor(u);
	bbox[1] = floor(v);
	bbox[2] = ceil(u);
	bbox[3] = ceil(v);
	int index1 = bbox[0] + (bbox[1] * n);
	int index2 = bbox[2] + (bbox[1] * n);
	int index3 = bbox[2] + (bbox[3] * n);
	int index4 = bbox[0] + (bbox[3] * n);
	//cout << "index " << index1 << " " << index2 << " " << index3 << " " << index4 << endl; 
	Vector_oper* P1 = data->at(index1);
	Vector_oper* P2 = data->at(index2);
	Vector_oper* P3 = data->at(index3);
	Vector_oper* P4 = data->at(index4);

	


	
	return Interpolation_cal(P1, P2, P3, P4, u, v ,bbox);
}

Vector_oper* AdvectwithRK4(int x, int y, int width, int height, double h, std::vector<Vector_oper*>* data, int n, int m)
{
	
	Vector_oper* Xn = new Vector_oper(x, y, 0);
 // 
	
	Vector_oper* K1 = EvaluateFieldAtLocation(x, y, data, n, m)->normalize();

	Vector_oper* K2 = NULL;
	int xn = x + (((double)h / 2.0) * K1->x);
	int yn = y + (((double)h / 2.0) * K1->y);
	if (xn >= 0 && xn < width && yn >= 0 && yn < height) 
	{
		K2 = EvaluateFieldAtLocation(xn, yn, data, n, m)->normalize();
	}
	else 
	{
		return new Vector_oper(-1, -1, 0);
	}

	Vector_oper* K3 = NULL;
	xn = x + (((double)h / 2.0) * K2->x);
	yn = y + (((double)h / 2.0) * K2->y);
	if (xn >= 0 && xn < width && yn >= 0 && yn < height)
	{
		K3 = EvaluateFieldAtLocation(xn, yn, data, n, m)->normalize();
	}
	else
	{
		return new Vector_oper(-1, -1, 0);
	}

	Vector_oper* K4 = NULL;
	xn = x + ((double)h * K3->x);
	yn = y + ((double)h * K3->y);
	if (xn >= 0 && xn < width && yn >= 0 && yn < height)
	{
		K4 = EvaluateFieldAtLocation(xn, yn, data, n, m)->normalize();
	}
	else
	{
		return new Vector_oper(-1, -1, 0);
	}

	
	Vector_oper* term1 = K1->clone();
	Vector_oper* term2 = K2->clone()->multiply(2.0);
	Vector_oper* term3 = K3->clone()->multiply(2.0);
	Vector_oper* term4 = K4->clone();
	Vector_oper* Xnext = term1->clone()->add(term2)->add(term3)->add(term4)->multiply(h / 6.0)->add(Xn);
	// cout << "next " << Xnext->x << " " << Xnext->y << endl; 

	
	return Xnext;
}

double getNoiseValue(int x, int y, vtkSmartPointer<vtkImageData> noise)
{
	
	unsigned char* RGB = static_cast<unsigned char*>(noise->GetScalarPointer(x, y, 0));


	int color = RGB[0];
	return color;
}



double average(std::vector<Vector_oper*>* values, vtkSmartPointer<vtkImageData> noise, int width, int height)
{
	
	size_t n = values->size();

	double avg;
	double sum = 0.0;
	int N = 0;

	
	for (int i = 0; i < n; i += 1) 
	{
		Vector_oper* p = values->at(i);
		int x = p->x;
		int y = p->y;

		if (x >= 0 && x < width && y >= 0 && y < height) 
		{
			double value = getNoiseValue(p->x, p->y, noise);
			sum += value;

			N += 1;
		}
	}
    avg =  sum / ((double)N);
	// cout << " avg" << avg << endl; 
	return avg;
}



std::vector<double>* getGaussianKernel(int L) 
{
	
	double E = (double)L / 2.0;

	
	std::vector<double>* gaussian = new std::vector<double>();

	
	for (int l = -L + 1; l < L; l += 1) 
	{
		
		double value = (1.0 / (E * sqrt(2 * M_PI))) * exp(-((l * l) / (2.0 * E * E)));
		//cout << "value " << value << endl;
		gaussian->push_back(value);
	}

	
	return gaussian;
}


std::vector<Vector_oper*>* getStreamLine(int x, int y, int width, int height, int L, double h, std::vector<Vector_oper*>* data, int n, int m, vtkSmartPointer<vtkImageData> noise)
{
	
	std::vector<Vector_oper*>* Forward = new std::vector<Vector_oper*>();

	
	int x0 = x;
	int y0 = y;
	
	for (int l = 0; l < L; l += 1) 
	{
		Forward->push_back(new Vector_oper(x0, y0, 0));
		
		if (x0 >= 0 && x0 < width && y0 >= 0 && y0 < height) 
		{
			
			Vector_oper* next = AdvectwithRK4(x0, y0, width, height, h, data, n, m);
			x0 = next->x;
			y0 = next->y;
			//cout << "x y " << x0 << " " << y0 << endl;
		
			
		}
		else
		{
			x0 = -1;
			y0 = -1;
		}
	}


	std::vector<Vector_oper*>* backward = new std::vector<Vector_oper*>();

	
	x0 = x;
	y0 = y;

	
	for (int l = 0; l > -L; l -= 1)
	{
		
		backward->push_back(new Vector_oper(x0, y0, 0));

		if (x0 >= 0 && x0 < width && y0 >= 0 && y0 < height) 
		{
			
			Vector_oper* next = AdvectwithRK4(x0, y0, width, height, -h, data, n, m);
			x0 = next->x;
			y0 = next->y;
			 //cout << " back " << x0 << " " << y0 << endl;
			
		}
		else 
		{
			x0 = -1;
			y0 = -1;
		}
	}

	std::vector<Vector_oper*>* streamline = new std::vector<Vector_oper*>();

	for (int i = L - 1; i >= 0; i -= 1) 
	{
		streamline->push_back(backward->at(i));
		
	}

	for (int i = 1; i < L; i += 1) 
	{
		streamline->push_back(Forward->at(i));
		
	}

	return streamline;
}


vtkSmartPointer<vtkImageData> LIC(int width, int height, int L, double h, std::vector<Vector_oper*>* data, int n, int m)
{
	
	vtkSmartPointer<vtkImageData> image = vtkSmartPointer<vtkImageData>::New();
	image->SetDimensions(width, height, 1);
	image->AllocateScalars(VTK_UNSIGNED_CHAR, 3);
	vtkSmartPointer<vtkImageData> noise = generateWhiteNoise(width, height);

	
	int length = (2 * L) - 1;
	std::vector<double>* gaussian = getGaussianKernel(L);
	


	
	for (int x = 0; x < height; x += 1)
	{
		for (int y = 0; y < width; y += 1)
		{
			std::vector<Vector_oper*>* streamline = getStreamLine(x, y, width, height, L, h, data, n, m, noise);
			size_t n = streamline->size();
			double avg = average(streamline, noise, width, height);
			double sum_num = 0.0;
			double sum_den = 0.0;
			for (int i = 0; i < length; i += 1) 
			{
				
				Vector_oper* p = streamline->at(i);
				int x0 = p->x;
				int y0 = p->y;

				
				if (x0 >= 0 && x0 < width && y0 >= 0 && y0 < height) 
				{
					sum_num += (getNoiseValue(x0, y0, noise) * gaussian->at(i));
					sum_den += gaussian->at(i);
					//sum_num += (getNoiseValue(x0, y0, noise) * avg);
					//sum_den += avg;
					
				}
			}
			
			
			double value = sum_num / sum_den;
			int color = (int)value;
			unsigned char* RGB = static_cast<unsigned char*>(image->GetScalarPointer(x, y, 0));
			RGB[0] = (unsigned char)(color);
			RGB[1] = (unsigned char)(color);
			RGB[2] = (unsigned char)(color);
		}
	}

	
	return image;
}

float *
Convert3DVectorDataTo2DVectorData(const int *dims, const float *F)
{
    float *rv = new float[dims[0]*dims[1]*2];
    int index3D = 0;
    int index2D = 0;
    for (int i = 0 ; i < dims[0] ; i++)
       for (int j = 0 ; j < dims[1] ; j++)
       {
           rv[index2D]   = F[index3D];
           rv[index2D+1] = F[index3D+1];
           index2D += 2;
           index3D += 3;
       }

    return rv;
}


int main(int argc, char** argv)
{
	vtkDataSetReader *rdr = vtkDataSetReader::New();
    rdr->SetFileName("proj4_data.vtk");
    rdr->Update();

    vtkDataSet* dataset = rdr->GetOutput();
    dataset->GetPointData()->SetActiveVectors("grad");
    int dims[3];
    vtkRectilinearGrid *rgrid = (vtkRectilinearGrid *) rdr->GetOutput();
    rgrid->GetDimensions(dims);

    float *X = (float *) rgrid->GetXCoordinates()->GetVoidPointer(0);
    float *Y = (float *) rgrid->GetYCoordinates()->GetVoidPointer(0);
    float *Z = (float *) rgrid->GetZCoordinates()->GetVoidPointer(0);

    float *F_3D = (float *) rgrid->GetPointData()->GetVectors()->GetVoidPointer(0);
    float *F = Convert3DVectorDataTo2DVectorData(dims, F_3D);
	int L = 10;
	int h = 5;
	int n, m;
	n = dims[0];
	m = dims[1];
	int length = n*m;
	std::vector<Vector_oper*>* data = new std::vector<Vector_oper*>();
	for(int i =0;i<length*2;i+=2){
		data->push_back(new Vector_oper(F[i], F[i+1], 0));
	}

	time_t start, end;
    time(&start);
	vtkSmartPointer<vtkImageData> image = LIC(256, 256, L, h, data, n, m);
	WriteImage(image, "LIC_10g ");
	time(&end);
  	double seconds;
 	seconds = difftime(end, start);
  	cout << "time " << seconds << endl;

	return EXIT_SUCCESS;
}
